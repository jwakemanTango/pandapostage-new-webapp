export interface ShipmentInput {
  fromAddress: {
    name: string;
    company?: string;
    phone: string;
    addressLine1: string;
    addressLine2?: string;
    city: string;
    state: string;
    zipCode: string;
    country: string;
  };
  toAddress: {
    name: string;
    company?: string;
    phone: string;
    addressLine1: string;
    addressLine2?: string;
    city: string;
    state: string;
    zipCode: string;
    country: string;
  };
  packageDetails: {
    weight: string;
    length?: string;
    width?: string;
    height?: string;
    packageType: string;
  };
  service?: string;
}

export interface Rate {
  id: string;
  carrierId?: number;
  service: string;
  carrier: string;
  rate: string;
  deliveryDays?: number;
  deliveryDate?: string;
}

export interface LabelResult {
  success: boolean;
  trackingNumber: string;
  labelUrl: string;
  providerId: string;
}

export interface TrackingResult {
  trackingNumber: string;
  status: string;
  statusDate?: string;
  lastUpdate?: string;
  deliveryDate?: string;
  events?: {
    timestamp: string;
    description: string;
    location?: string;
  }[];
}

export interface ShippingProvider {
  getRates(shipment: ShipmentInput): Promise<Rate[]>;
  createLabel(shipment: ShipmentInput): Promise<LabelResult>;
  refundLabel(labelId: string): Promise<boolean>;
  trackLabel(trackingNumber: string): Promise<TrackingResult>;
}
