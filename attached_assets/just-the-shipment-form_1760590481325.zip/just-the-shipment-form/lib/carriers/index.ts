import { MockShippingProvider } from "./mock-provider";
import { ShippingProvider } from "./types";

export class ShippingProviderFactory {
  getProviderByType(type: string): ShippingProvider {
    switch (type) {
      case 'mock':
        return new MockShippingProvider();
      // Add additional provider implementations here as they are created
      default:
        // Default to mock provider
        console.warn(`Provider type ${type} not implemented, falling back to mock provider`);
        return new MockShippingProvider();
    }
  }
}

export { MockShippingProvider };
export * from "./types";
