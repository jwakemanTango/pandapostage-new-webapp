import { ShippingProvider, ShipmentInput, Rate, LabelResult, TrackingResult } from "./types";

export class MockShippingProvider implements ShippingProvider {
  private generateMockRates(): Rate[] {
    return [
      {
        id: "rate_usps_priority",
        service: "Priority Mail",
        carrier: "USPS",
        rate: "$7.95",
        deliveryDays: 2
      },
      {
        id: "rate_usps_express",
        service: "Priority Mail Express",
        carrier: "USPS",
        rate: "$25.50",
        deliveryDays: 1
      },
      {
        id: "rate_fedex_ground",
        service: "Ground",
        carrier: "FedEx",
        rate: "$10.75",
        deliveryDays: 3
      },
      {
        id: "rate_ups_ground",
        service: "UPS Ground",
        carrier: "UPS",
        rate: "$11.25",
        deliveryDays: 3
      },
      {
        id: "rate_ups_2day",
        service: "UPS 2nd Day Air",
        carrier: "UPS",
        rate: "$18.75",
        deliveryDays: 2
      }
    ];
  }

  private generateTrackingNumber(): string {
    const prefix = ["1Z", "9400", "7777", "FX"];
    const chosenPrefix = prefix[Math.floor(Math.random() * prefix.length)];
    const digits = "0123456789";
    let tracking = chosenPrefix;
    
    // Generate random digits to complete tracking number
    for (let i = 0; i < 12; i++) {
      tracking += digits.charAt(Math.floor(Math.random() * digits.length));
    }
    
    return tracking;
  }

  async getRates(shipment: ShipmentInput): Promise<Rate[]> {
    // Simulate network delay
    await new Promise(resolve => setTimeout(resolve, 500));
    
    // Return mock rates
    return this.generateMockRates();
  }

  async createLabel(shipment: ShipmentInput): Promise<LabelResult> {
    // Simulate network delay
    await new Promise(resolve => setTimeout(resolve, 800));
    
    const trackingNumber = this.generateTrackingNumber();
    
    return {
      success: true,
      trackingNumber,
      labelUrl: `https://example.com/labels/${trackingNumber}.pdf`,
      providerId: `mock_${Date.now()}`
    };
  }

  async refundLabel(labelId: string): Promise<boolean> {
    // Simulate network delay
    await new Promise(resolve => setTimeout(resolve, 300));
    
    // 80% chance of successful refund
    return Math.random() < 0.8;
  }

  async trackLabel(trackingNumber: string): Promise<TrackingResult> {
    // Simulate network delay
    await new Promise(resolve => setTimeout(resolve, 400));
    
    // Generate a random status
    const statuses = ["Delivered", "In Transit", "Out for Delivery", "Pending"];
    const status = statuses[Math.floor(Math.random() * statuses.length)];
    
    // Generate random dates
    const today = new Date();
    const statusDate = new Date(today);
    statusDate.setDate(today.getDate() - Math.floor(Math.random() * 3));
    
    const deliveryDate = new Date(today);
    if (status !== "Delivered") {
      deliveryDate.setDate(today.getDate() + Math.floor(Math.random() * 5) + 1);
    }
    
    // Generate tracking events
    const events = [];
    
    if (status === "Delivered" || status === "In Transit") {
      events.push({
        timestamp: statusDate.toISOString(),
        description: "Shipment picked up",
        location: "Origin Facility"
      });
    }
    
    if (status === "Delivered" || status === "Out for Delivery") {
      const inTransitDate = new Date(statusDate);
      inTransitDate.setDate(statusDate.getDate() + 1);
      
      events.push({
        timestamp: inTransitDate.toISOString(),
        description: "In transit",
        location: "Regional Facility"
      });
    }
    
    if (status === "Delivered") {
      events.push({
        timestamp: today.toISOString(),
        description: "Delivered",
        location: "Destination"
      });
    } else if (status === "Out for Delivery") {
      events.push({
        timestamp: today.toISOString(),
        description: "Out for delivery",
        location: "Local Facility"
      });
    }
    
    return {
      trackingNumber,
      status,
      statusDate: statusDate.toISOString(),
      lastUpdate: today.toISOString(),
      deliveryDate: deliveryDate.toISOString(),
      events
    };
  }
}
